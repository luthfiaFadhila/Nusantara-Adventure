 const slides = document.querySelector('.slides');
    const slide = document.querySelectorAll('.slide');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    let counter = 0;
    const size = slide[0].clientWidth;

    nextBtn.addEventListener('click', () => {
        if (counter >= slide.length - 1) return;
        slides.style.transition = "transform 0.5s ease-in-out";
        counter++;
        slides.style.transform = 'translateX(' + (-size * counter) + 'px)';
    });

    prevBtn.addEventListener('click', () => {
        if (counter <= 0) return;
        slides.style.transition = "transform 0.5s ease-in-out";
        counter--;
        slides.style.transform = 'translateX(' + (-size * counter) + 'px)';
    });